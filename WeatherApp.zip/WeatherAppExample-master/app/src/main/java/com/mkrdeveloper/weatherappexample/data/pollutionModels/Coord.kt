package com.mkrdeveloper.weatherappexample.data.pollutionModels

data class Coord(
    val lat: Double,
    val lon: Double
)