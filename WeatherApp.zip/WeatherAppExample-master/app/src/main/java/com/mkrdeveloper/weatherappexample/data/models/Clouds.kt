package com.mkrdeveloper.weatherappexample.data.models

data class Clouds(
    val all: Int
)