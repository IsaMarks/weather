package com.mkrdeveloper.weatherappexample.data.forecastModels

data class Sys(
    val pod: String
)