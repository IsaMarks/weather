package com.mkrdeveloper.weatherappexample.data

data class CitySuggestion(
    val name: String
)
