package com.mkrdeveloper.weatherappexample.data.forecastModels

data class Clouds(
    val all: Int
)