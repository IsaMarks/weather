package com.mkrdeveloper.weatherappexample

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.bottomsheet.BottomSheetDialog
//import com.google.android.material.internal.ViewUtils.hideKeyboard
import com.mkrdeveloper.weatherappexample.adapter.RvAdapter
import com.mkrdeveloper.weatherappexample.data.forecastModels.ForecastData
import com.mkrdeveloper.weatherappexample.databinding.ActivityMainBinding
import com.mkrdeveloper.weatherappexample.databinding.BottomSheetLayoutBinding
import com.mkrdeveloper.weatherappexample.utils.RetrofitInstance
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    //private lateinit var sheetLayoutBinding: BottomSheetLayoutBinding
    private lateinit var dialog: BottomSheetDialog
    private var city: String = "Salvador,Br"
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    private fun String.isCityInBrazil(): Boolean {
        val geocoder = Geocoder(this@MainActivity, Locale.getDefault())
        val addresses: List<Address> = geocoder.getFromLocationName(this, 1) as List<Address>
        if (addresses.isNotEmpty()) {
            val address = addresses[0]
            if (address.countryCode.equals("BR", ignoreCase = true)) {
                return true
            }
        }
        return false
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.searchView.windowToken, 0)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        //sheetLayoutBinding = BottomSheetLayoutBinding.inflate(layoutInflater)
        dialog = BottomSheetDialog(this, R.style.BottomSheetTheme)
       // dialog.setContentView(sheetLayoutBinding.root)

        setContentView(binding.root)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    city = query
                    getCurrentWeather(city)

                    // Esconde o teclado após o usuário pressionar o botão de busca
                    hideKeyboard()
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return true
            }
        })
        getCurrentLocationWeather()

        binding.tvLocation.setOnClickListener {
            getCurrentLocationWeather()
        }
    }

        /*binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    city = query
                    getCurrentWeather(city)

                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return true
            }
        })

        getCurrentLocationWeather()

        /*binding.tvForecast.setOnClickListener {
            openDialog()
        }*/

        binding.tvLocation.setOnClickListener {
            getCurrentLocationWeather()
        }
    }*/

    private fun getCurrentLocationWeather() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
            return
        }

        fusedLocationProviderClient.lastLocation.addOnSuccessListener { location: Location? ->
            location?.let {
                val geocoder = Geocoder(this, Locale.getDefault())
                val addresses: List<Address> = geocoder.getFromLocation(it.latitude, it.longitude, 1) as List<Address>

                if (addresses.isNotEmpty()) {
                    val cityName = addresses[0].locality

                    if (!cityName.isNullOrEmpty() && cityName.isCityInBrazil()) {
                        city = cityName
                    }

                    getCurrentWeather(city)
                }
            }

        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == 101) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permissão concedida, execute a lógica para obter a localização atual
                getCurrentLocationWeather()
            } else {
                // Permissão negada, informe ao usuário ou trate o caso adequadamente
                Toast.makeText(applicationContext, "Permissão de localização negada", Toast.LENGTH_SHORT).show()
            }
        }
    }


    /*private fun openDialog() {
        getForecast()
        dialog.window?.attributes?.windowAnimations = R.style.DialogAnimation
        dialog.show()
    }

    @SuppressLint("SetTextI18n")
    private fun getForecast() {
        GlobalScope.launch(Dispatchers.IO) {
            try {
                val response = RetrofitInstance.api.getForecast(
                    city,
                    "metric",
                    applicationContext.getString(R.string.api_key)
                )

                if (response.isSuccessful && response.body() != null) {
                    val data = response.body()!!
                    val forecastArray: ArrayList<ForecastData> = data.list as ArrayList<ForecastData>

                    runOnUiThread {
                        val adapter = RvAdapter(forecastArray)
                        sheetLayoutBinding.rvForecast.adapter = adapter
                        sheetLayoutBinding.rvForecast.layoutManager = GridLayoutManager(this@MainActivity, 1, RecyclerView.HORIZONTAL, false)
                        sheetLayoutBinding.tvSheet.text = "Previsão de cinco dias em ${data.city.name}"
                    }
                }
            } catch (e: IOException) {
                showToast("Erro de conexão")
            } catch (e: HttpException) {
                showToast("Erro no servidor")
            }
        }
    }*/


    @SuppressLint("SetTextI18n")
    private fun getCurrentWeather(city: String) {
        GlobalScope.launch(Dispatchers.IO) {
            try {
                val response = RetrofitInstance.api.getCurrentWeather(
                    city,
                    "metric",
                    applicationContext.getString(R.string.api_key)
                )

                if (response.isSuccessful && response.body() != null) {
                    withContext(Dispatchers.Main) {
                        val data = response.body()!!

                        val iconId = data.weather[0].icon
                        val imgUrl = "https://openweathermap.org/img/wn/$iconId@4x.png"
                        Picasso.get().load(imgUrl).into(binding.imgWeather)

                        binding.tvSunset.text = dateFormatConverter(data.sys.sunset.toLong())
                        binding.tvSunrise.text = dateFormatConverter(data.sys.sunrise.toLong())

                        binding.apply {
                            tvStatus.text = data.weather[0].description
                            tvWind.text = "${data.wind.speed} KM/H"
                            tvLocation.text = "${data.name}, ${data.sys.country}"
                            tvTemp.text = "${data.main.temp.toInt()}°C"
                            tvFeelsLike.text = "Sensação térmica: ${data.main.feels_like.toInt()}°C"
                            tvMinTemp.text = "Temp.mín: ${data.main.temp_min.toInt()}°C"
                            tvMaxTemp.text = "Temp.máx: ${data.main.temp_max.toInt()}°C"
                            tvHumidity.text = "${data.main.humidity} %"
                            tvPressure.text = "${data.main.pressure} hPa"
                            tvUpdateTime.text = "Última atualização: ${dateFormatConverter(data.dt.toLong())}"
                        }
                    }
                }
            } catch (e: IOException) {
                showToast("Erro de conexão")
            } catch (e: HttpException) {
                showToast("Erro no servidor")
            }
        }
    }

    private fun isCityInBrazil(cityName: String, countryName: String): Boolean {
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses: List<Address> = geocoder.getFromLocationName(cityName, 1) as List<Address>
        if (addresses.isNotEmpty()) {
            val address = addresses[0]
            if (address.countryName == "Brazil" || address.countryCode == "BR") {
                return true
            }
        }
        return false
    }

    private fun showToast(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
    }

    private fun dateFormatConverter(date: Long): String {
        return SimpleDateFormat("HH:mm a", Locale.getDefault()).format(Date(date * 1000))
    }
}
