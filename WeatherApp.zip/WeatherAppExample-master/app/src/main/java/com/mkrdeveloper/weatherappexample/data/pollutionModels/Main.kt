package com.mkrdeveloper.weatherappexample.data.pollutionModels

data class Main(
    val aqi: Int
)