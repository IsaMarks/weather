package com.mkrdeveloper.weatherappexample.data.forecastModels

data class Coord(
    val lat: Double,
    val lon: Double
)