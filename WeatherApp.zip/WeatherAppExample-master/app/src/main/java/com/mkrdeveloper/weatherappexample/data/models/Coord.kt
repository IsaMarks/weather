package com.mkrdeveloper.weatherappexample.data.models

data class Coord(
    val lat: Double,
    val lon: Double
)